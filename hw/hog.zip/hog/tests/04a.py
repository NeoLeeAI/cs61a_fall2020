test = {
  'name': 'Question 4a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> swine_align(2, 4)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(11, 22)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(36, 24)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(27, 13)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(23, 22)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(15, 45)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(15, 0)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(47, 64)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(12, 72)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(15, 72)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(24, 3)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(46, 55)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(91, 78)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(73, 99)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(23, 92)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(51, 68)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(92, 54)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(77, 22)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(48, 32)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(50, 80)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(48, 74)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(10, 10)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(12, 5)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(96, 16)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(26, 91)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(19, 69)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(93, 62)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(90, 15)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(48, 84)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(38, 19)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(57, 19)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(3, 64)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(62, 90)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(30, 15)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(33, 66)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(45, 60)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(96, 24)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(26, 78)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(87, 16)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(77, 11)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(7, 88)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(85, 68)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(76, 19)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(70, 80)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(28, 84)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(65, 13)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(20, 70)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(91, 7)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(35, 12)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(51, 92)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(64, 49)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(35, 45)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(24, 12)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(55, 22)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(42, 56)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(51, 81)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(45, 40)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(96, 11)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(57, 96)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(13, 65)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(44, 77)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(52, 13)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(26, 39)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(31, 31)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(98, 56)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(66, 99)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(44, 77)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(17, 34)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(15, 45)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(24, 81)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(11, 87)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(38, 54)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(63, 40)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(60, 51)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(60, 84)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(50, 75)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(75, 73)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(86, 24)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(48, 16)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(19, 46)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(18, 46)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(91, 9)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(19, 81)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(72, 60)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(63, 21)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(26, 13)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(54, 36)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(24, 24)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(48, 84)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(70, 70)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(23, 39)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(89, 56)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(32, 13)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(96, 44)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(77, 59)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(32, 79)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(30, 90)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(33, 77)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(46, 82)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(42, 67)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(52, 52)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(90, 75)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(41, 19)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(90, 38)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(35, 51)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(42, 52)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> swine_align(62, 62)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': r"""
      >>> from hog import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
